class ToolProviderCredentialValidationError(Exception):
    pass
